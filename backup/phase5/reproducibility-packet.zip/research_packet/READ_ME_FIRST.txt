AM316L public-data collection and rotating-bending pilot - phase5

20 October2026. Local research checkpoint, not a submission or new safety guarantee.
Start with manuscript/v5/public_data_rbf_addendum_en.pdf or the Turkish report.

Reproduce the frozen RBF experiments with: zsh run_v5.sh
Python3.12.13 was used, dependencies are pinned in requirements.lock.txt.
The supplied hashes, target queries, source-family exclusion and code are checked.
No model/task pickle cache is included. A fresh empty-cache run reproduced all36
scientific CSVs and every fitted parameter/diagnostic, excluding elapsed time.
Predictions and selections repeat67source points; they are not physical test counts.

Training input is unchanged at441. PrimaryRBF25C44rows and450C23rows are separate.
All67 belong to one related source family;25ambientasbuilt points are explicitly
borrowed from108491. Exact physical specimen/build/virgin identities unverified.
5M support cost is identifiable truncated exposure. At10M use the dedicated
policy_cost_savings_bounds.csv, not inherited lower-bound support_cycle_change
as if it were exact cost. One-family confidence gates are explicitly unevaluable.
The intercept model's k0 diagnostic shift fields can be stale; its predictions
use the correct hierarchical reference. Read diagnostic_scope_note/code audit.

New source collection:44exactPINNfamilyNf,12exactstraincontrolledNf,16approximate
Faue markers, plus13source-fittedstrengthparameters. These roles are separate.
No invented specimen/batch links, future fracture covariates or source mean curves.
The PINN44 have no row-to-three-batch map or complete censor inventory and are
not reliability/acquisition fit inputs. All original source discrepancies retained.
Source URLs, hashes, licenses, qualifications and transformation code are supplied.

Article full texts, PDFs/XML/HTML/images, original author workbooks and authorcode
are excluded. PublicPINNworkbook can optionally be reacquired from publisher and
fixed authorcommit via python -m src.v5_pinn_acquire, then imported with
python -m src.v5_pinn_import. No downloaded authorcode is executed.
Graph extraction cannot be reproduced from an automatic raw-image pipeline here:
reported approximate coordinates and pixel decisions are the curated input.

The user moved the working source folder toDesktop during execution; code/input
hashes remained unchanged. Canonical runtime root is computed from sourcefile.
No correspondence or publication occurred. The goal remains active: stronger
method/tuning comparisons and a second independently mapped campaign are open.
