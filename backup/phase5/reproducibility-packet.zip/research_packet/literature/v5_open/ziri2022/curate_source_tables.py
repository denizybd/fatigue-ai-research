"""Reproduce source-qualified Ziri thesis tables and a future figure-anchor inventory.

No author physical specimen ID, build ID, exact life, or virgin-exposure status is
invented. The 11 table IDs are parameter-set IDs. The nine figure locators are
unreviewed curator pixel anchors only; no numeric life points are admitted.
"""
from pathlib import Path
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[3]
LIT = ROOT / 'literature/v5_open/ziri2022'
OUT = ROOT / 'data/external_v5/ziri2022'
OUT.mkdir(parents=True, exist_ok=True)
PDF_URL = 'https://depozit.isae.fr/theses/2022/2022_Ziri_Sabrine.pdf'
THESIS_DOI = '10.70675/9d9ce3ceze624z48f1z8ff5zbc47a5a90c47'
FAMILY = 'Ziri_Hor_Mabru_2022thesis_ffe14506'


def write_csv(name, rows):
    with (OUT / name).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


# These source rows deliberately use the author's parameter-set number, not an
# artificial physical specimen ID. Tables5.3/5.5 describe the corresponding sets.
# id,powder,Ev,P,v,L_um,porosity_percent,max_ESD_mm,UTS,YS,elongation,selfheat_limit
source_sets = [
    (1,'Type3-S34',65.5,275,700,50,.06,.35,560,466,45,130),
    (2,'Type3-S34',114.6,275,400,50,.06,.381,559,475,48,140),
    (3,'Type3-S34',145.8,350,400,50,.03,.25,556,470,38,150),
    (4,'Type2-H27',65.5,275,700,50,.93,.5,429,349,20,100),
    (5,'Type2-H27',114.6,275,400,50,.07,.292,471,384,49,100),
    (6,'Type2-H27',145.8,350,400,50,.01,.25,478,386,41,120),
    (7,'Type2-H27',208.3,350,400,35,.002,.117,454,353,67,140),
    (8,'Type4-H67',65.5,275,700,50,.003,.044,512,420,76,130),
    (9,'Type4-H67',114.6,275,400,50,.49,.532,479,388,37,130),
    (10,'Type4-H67',145.8,350,400,50,.2,.5,469,380,33,140),
    (11,'Type4-H67',208.3,350,400,35,.01,.156,486,408,63,110),
]
sets = []
for i,pow,ev,p,v,l,por,esd,uts,ys,elong,sh in source_sets:
    sets.append(dict(
        author_parameter_set_id=i, id_semantics='powder_process_condition_not_physical_specimen',
        author_powder_designation=pow,
        author_powder_name={'Type3-S34':'Standard-S34','Type2-H27':'Standard-H27','Type4-H67':'Coarse-H67'}[pow],
        material='SS316L', process='LPBF', build_orientation='vertical',
        laser_power_W=p, scan_velocity_mm_per_s=v, layer_thickness_um=l,
        reported_energy_density_J_per_mm3=ev, hatch_distance_um=120,
        scan_stripe_rotation_deg=33, scan_stripe_length_mm=10,
        source_set_porosity_percent=por, source_set_max_ESD_mm=esd,
        source_set_UTS_MPa=uts, source_set_YS_MPa=ys, source_set_elongation_percent=elong,
        selfheating_estimated_fatigue_limit_MPa=sh,
        selfheating_limit_is_CA_life_record=False,
        exact_individual_SN_records_in_table=0,
        author_physical_specimen_id='', actual_build_id='', actual_build_count='',
        commercial_powder_lot_id='', actual_specimen_to_life_link='',
        powder_batch_scope=('one supplied S34 batch used for all builds; no commercial lot ID'
            if pow=='Type3-S34' else 'one supplied H67 batch used for all builds; no commercial lot ID'
            if pow=='Type4-H67' else 'first and second H27 batches mixed for diameter13mm cylinder builds; proportions and per-specimen crosswalk absent'),
        condition_properties_are_individual_pretest_covariates=False,
        gold_identity_eligible=False, model_fit_eligible=False,
        source_tables='5.2;5.3;5.5;5.6',
        source_pdf_pages='175;176;181;191', source_printed_pages='161;162;167;177',
        general_build_source_pdf_pages='69;70;71;147;177', source_doi=THESIS_DOI,
        source_url=PDF_URL, precautionary_source_family=FAMILY))
write_csv('powder_process_sets11.csv', sets)

powders = []
for designation,supplier,atomization,d10,d50,d90,rhoa,rhor,flow,nbatch,batch_note in [
    ('Type2-H27','Höganäs','argon',19.3,29.2,43.1,4500,56.6,17.5,2,
     'Two separately bought batches; first and second mixed for diameter13mm cylinders. No commercial lot IDs, mix proportions or specimen-life link.'),
    ('Type3-S34','SLM Solutions','nitrogen',30.1,41.2,56.2,4560,57.4,16.9,1,
     'One supplied batch used for all builds. This does not establish a single physical build.'),
    ('Type4-H67','Höganäs','argon',53.3,73,100,4210,53,15,1,
     'One supplied batch used for all builds; same reference batch as initial H27/FineH6 per author. No commercial lot ID.'),
]:
    powders.append(dict(author_powder_designation=designation,supplier=supplier,
        atomization_gas=atomization,D10_um=d10,D50_um=d50,D90_um=d90,
        apparent_density_kg_per_m3=rhoa,relative_density_percent=rhor,Hall_flowability_s=flow,
        source_reported_supplied_batch_count=nbatch,commercial_lot_id='',
        actual_build_id='',actual_build_count='',batch_scope_note=batch_note,
        source_pdf_pages='61;63;69;147',source_printed_pages='47;49;55;133',
        source_url=PDF_URL,source_doi=THESIS_DOI))
write_csv('powder_source_catalog3.csv', powders)

chem = []
for label,si,s,p,o,n,c,ni,mn,mo,cr in [
    ('Höganäs Batch1 (includes Type2-H27 first batch)','<0.1',.002,'<0.01',.04,.01,0,13.6,1.5,2.7,17.7),
    ('Type2-H27 Batch2',.2,.004,'<0.01',.04,.01,0,11.9,1.5,2.3,17.7),
]:
    chem.append(dict(author_batch_label=label,Si_wt_percent=si,S_wt_percent=s,P_wt_percent=p,
        O_wt_percent=o,N_wt_percent=n,C_wt_percent=c,Ni_wt_percent=ni,Mn_wt_percent=mn,
        Mo_wt_percent=mo,Cr_wt_percent=cr,Fe='Balance',commercial_lot_id='',
        physical_specimen_id='',actual_build_id='',source_table='4.4',
        source_pdf_page=148,source_printed_page=134,source_url=PDF_URL))
write_csv('h27_author_batch_chemistry2.csv',chem)

common = dict(material='SS316L',process='LPBF',machine='Instron8874_25kN_servohydraulic',
    geometry='machined from vertical diameter13mm cylinders; polished; AppendixI final geometry',
    R=-1,thermal_treatment='no heat treatment reported for HCF specimens',
    actual_physical_ID_to_SN_link=False,actual_build_ID_to_SN_link=False,
    physical_virgin_first_exposure_verified=False,source_doi=THESIS_DOI,source_url=PDF_URL,
    precautionary_source_family=FAMILY)
methods = [dict(panel='selfheating',**common,
    loading='uniaxial cyclic loading with increasing stress increments and cooldown',
    constant_amplitude_single_level_life_panel=False,frequency_Hz=10,
    stress_min_reported_MPa=50,stress_max_reported_MPa=300,stress_definition='maximum stress',
    environment_reported='ambient conditions',temperature_C='',
    feedback_control_mode_explicit='',cycles_per_increment_min=3000,
    per_set_repeat_statement='two repetitions on two different samples',
    exact_campaign_specimen_count='',source_campaign_specimen_count_statement='',
    source_runout_threshold_cycles='',individual_Nf_or_event_table_present=False,
    selfheating_relation_to_HCF_specimens='no physical crosswalk; cannot establish same or different specimens',
    source_pdf_pages='182;183',source_printed_pages='168;169',
    acquisition_eligible=False,reliability_fit_eligible=False),
    dict(panel='HCF',**common,
    loading='fully reversed axial tension-compression S-N tests; maximum stress specified',
    constant_amplitude_single_level_life_panel=True,frequency_Hz=20,
    stress_min_reported_MPa=130,stress_max_reported_MPa=300,stress_definition='maximum stress; equals amplitude for R=-1 by algebra',
    environment_reported='',temperature_C='',feedback_control_mode_explicit='',
    cycles_per_increment_min='',per_set_repeat_statement='',
    exact_campaign_specimen_count='',source_campaign_specimen_count_statement='approximately40 for all set combinations',
    source_runout_threshold_cycles=2000000,individual_Nf_or_event_table_present=False,
    selfheating_relation_to_HCF_specimens='same geometry and machine; prior loading history not explicitly specified',
    source_pdf_pages='186;191;192',source_printed_pages='172;177;178',
    acquisition_eligible=False,reliability_fit_eligible=False)]
# Enforce identical keys in the two method rows.
keys=list(dict.fromkeys(k for row in methods for k in row))
methods=[{k:row.get(k,'') for k in keys} for row in methods]
write_csv('method_panels2.csv',methods)

# Deliberately partial, unreviewed future graphical candidates. Source coordinates
# in the ORIGINAL PDF-embedded 1417x1084 JPEG, origin top-left. Original marker
# colours/shapes are separated from Merot/Blinn/Roirand/Liang literature overlays.
# These are not author specimen IDs, numeric life records, or a complete sample.
# Coordinate envelope is an operational +/-3pixel sensitivity, not a CI.
# Triangle y is the plot anchor (geometric centroid), not bounding-box midpoint.
picked = [
    ('F5.13_px701_426','Type2-H27',65.5,'circle',701,426),
    ('F5.13_px927_426','Type2-H27',208.3,'star',927,426),
    ('F5.13_px1030_763','Type2-H27',65.5,'circle',1030,763),
    ('F5.13_px619_369','Type3-S34',65.5,'circle',619,369),
    ('F5.13_px987_817','Type3-S34',65.5,'circle',987,817),
    ('F5.13_px742_540','Type3-S34',145.8,'triangle',742,540),
    ('F5.13_px774_370','Type4-H67',65.5,'circle',774,370),
    ('F5.13_px1003_764','Type4-H67',208.3,'star',1003,764),
    ('F5.13_px585_623','Type4-H67',145.8,'triangle',585,623),
]
calibration=dict(image='pdfpage192_embedded0_Im194.jpg',image_width_px=1417,image_height_px=1084,
    x_left_px=219,x_right_px=1371,x_left_cycles=10000,x_right_cycles=10000000,
    y_top_px=61,y_bottom_px=904,y_top_MPa=400,y_bottom_MPa=100,
    coordinate_sensitivity_px=3,coordinate_sensitivity_is_confidence_interval=False,
    selection='Nine conservative pixel anchors for future independent review only; overlapping markers and runout cluster not digitized. No numeric S,N admission. Not an exhaustive campaign sample.',
    classification='unreviewed_future_pixel_anchor_inventory_not_life_records',
    actual_specimen_ID_mapping_available=False,figure_literature_overlays_excluded=True)
(LIT/'figure5_13_calibration.json').write_text(json.dumps(calibration,indent=2))
approx=[]
for loc,pow,ev,shape,x,y in picked:
    approx.append(dict(curator_figure_locator=loc,locator_is_author_specimen_id=False,
        author_physical_specimen_id='',actual_build_id='',commercial_powder_lot_id='',
        author_powder_designation=pow,reported_energy_density_J_per_mm3=ev,
        marker_shape=shape,source_figure='5.13',source_pdf_page=192,source_printed_page=178,
        source_image='pdfpage192_embedded0_Im194.jpg',pixel_x=x,pixel_y=y,
        digitization_class='unreviewed_future_pixel_anchor_not_admitted_life_record',
        R=-1,exact_author_reported_N='',digitized_N_cycles='',digitized_Smax_MPa='',
        event_interpretation='',event_is_exact_author_numeric_table=False,
        source_HCF_runout_threshold_cycles=2000000,
        frequency_Hz=20,temperature_C='',feedback_control_mode='',
        prior_loading_history='',physical_first_exposure_verified=False,
        complete_campaign_sample=False,representative_random_sample=False,
        selection_eligible=False,reliability_fit_eligible=False,model_fit_eligible=False,
        source_url=PDF_URL,source_doi=THESIS_DOI,precautionary_source_family=FAMILY))
with (LIT/'figure5_13_unreviewed_future_pixel_anchors9.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(approx[0]));w.writeheader();w.writerows(approx)
# The exploratory numeric draft was never admitted, modeled or delivered. Remove
# it rather than leave a misleading nine-life CSV beside the source tables.
(OUT/'figure5_13_partial_approx9.csv').unlink(missing_ok=True)

receipt=dict(author_parameter_sets=len(sets),powder_type_rows=len(powders),
    author_batch_chemistry_rows=len(chem),separate_method_panels=len(methods),
    unreviewed_future_pixel_anchors=len(approx),admitted_approximate_life_rows=0,exact_numeric_individual_SN_records=0,
    physical_ID_to_build_to_SN_qualified_records=0,new_verified_gold_campaigns=0,
    approximate_rows_are_not_complete_or_unbiased_sample=True,
    exact_physical_HCF_count_unknown=True,raw_report_approximately40_is_not_forced_row_count=True,
    no_R_point1_records_from_thesis_HCF=True,postfracture_SEM_not_exported_as_pretest_covariates=True,
    no_models_fitted=True,source_pdf_sha256=hashlib.sha256((LIT/'official_document_http.pdf').read_bytes()).hexdigest())
(OUT/'curation_receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
