"""Independent saved-output audit. Imports no project model/summary functions."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
FAMILY = 'Behvar_Aghayar_108491_109365'
BASE = ROOT / 'data/processed/v5/rbf'
TARGET = pd.read_csv(BASE / 'target.csv').set_index('row_id', drop=False)
SPLITS = json.loads((BASE / 'frozen_splits.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
MODELS = {'pooled','hierarchical','curved_hierarchical','rfl','matched_intercept','local_slope'}
POLICIES = {'random','high_stress','stress_span','active_query_variance'}


def balanced_means(meta, values):
    """Explicit condition -> seed -> family averaging, including finite subsets."""
    columns = list(values)
    z = pd.DataFrame(values).reset_index(drop=True)
    z[['family','condition','seed']] = meta[['campaign_id','dataset_id','seed']].to_numpy()
    family_rows = []
    for _, family in z.groupby('family'):
        seed_rows = []
        for _, seed in family.groupby('seed'):
            condition_rows = []
            for _, condition in seed.groupby('condition'):
                condition_rows.append([condition[c].dropna().mean() for c in columns])
            seed_rows.append(pd.DataFrame(condition_rows).mean().to_numpy())
        family_rows.append(pd.DataFrame(seed_rows).mean().to_numpy())
    result = pd.DataFrame(family_rows, columns=columns)
    return {c: (float(result[c].mean()),int(result[c].notna().sum())) for c in columns}


def paired_values(a, b, include_cost):
    # Derive indicator differences on failures, and sharp bounds on T>c queries.
    qa = a.log_lower.to_numpy(); qb = b.log_lower.to_numpy()
    stop = a.log_life.to_numpy(); event = a.event.to_numpy()
    valid = ~(np.isnan(qa) | np.isnan(qb))
    finite = np.isfinite(qa) & np.isfinite(qb)
    lo = np.empty(len(a)); hi = np.empty(len(a))
    for i in range(len(a)):
        if not valid[i]: lo[i],hi[i] = -1.0,1.0
        elif event[i] == 1:
            lo[i] = hi[i] = float(qa[i] > stop[i])-float(qb[i] > stop[i])
        elif qa[i] > qb[i] and qa[i] > stop[i]: lo[i],hi[i] = 0.0,1.0
        elif qb[i] > qa[i] and qb[i] > stop[i]: lo[i],hi[i] = -1.0,0.0
        else: lo[i] = hi[i] = 0.0
    gain = np.full(len(a),np.nan)
    gain[finite] = qa[finite]-qb[finite]
    out = dict(paired_availability=valid.astype(float),
        paired_finite_availability=finite.astype(float),log_life_gain=gain,
        true_risk_change_lo=lo,true_risk_change_hi=hi)
    if include_cost:out['support_cycle_change']=a.support_cycles.to_numpy()-b.support_cycles.to_numpy()
    return out


def compare_table(expected, path, keys):
    actual = pd.read_csv(path)
    index = keys+['metric']
    assert not actual.duplicated(index).any()
    assert not expected.duplicated(index).any()
    a=actual.set_index(index).sort_index(); b=expected.set_index(index).sort_index()
    assert a.index.equals(b.index),path.name+' keys differ'
    assert a.n_campaigns.eq(1).all()
    assert a[['lo95','hi95']].isna().all().all()
    assert np.array_equal(a.n_finite_campaigns,b.n_finite_campaigns)
    errors={}
    for metric in a.index.get_level_values('metric').unique():
        aa=a.xs(metric,level='metric')['mean'];bb=b.xs(metric,level='metric')['mean']
        assert aa.isna().equals(bb.isna())
        error=float(np.max(np.abs(aa-bb)))
        errors[metric]=error
        assert np.allclose(aa,bb,rtol=1e-12,atol=(1e-7 if metric=='support_cycle_change' else 2e-13),equal_nan=True),(path.name,metric,error)
    return dict(rows=len(actual),all_keys_match=True,max_abs_error_by_metric=errors,
        n_campaigns=1,all_confidence_endpoints_unavailable=True)


def check_math():
    cases=0
    for qa,qb in itertools.product([-math.inf,-1.,0.,.2,1.,math.inf],repeat=2):
        c=0.;lo=-float(qb>qa and qb>c);hi=float(qa>qb and qa>c)
        boundaries=sorted({c,*[q for q in [qa,qb] if np.isfinite(q) and q>c]})
        witnesses=[*boundaries[1:],math.inf,boundaries[-1]+1.]
        witnesses += [(x+y)/2 for x,y in zip(boundaries[:-1],boundaries[1:])]
        witnesses=[x for x in witnesses if x>c]
        deltas=[float(qa>t)-float(qb>t) for t in witnesses]
        assert lo==min(deltas) and hi==max(deltas),(qa,qb,lo,hi,deltas)
        cases+=1
    return dict(sharp_censor_order_cases=cases,includes_infinite_prediction_and_lifetime_cases=True,
        risk_definition='I(q10>true finite/event life); censored T>c yields ordered-threshold identification bounds',
        finite_utility='log10(q10_A)-log10(q10_B), restricted to jointly finite predictions; availability reported separately')


def audit(folder):
    d=pd.read_csv(folder/'predictions.csv');sel=pd.read_csv(folder/'selections.csv')
    cap=float(d.cap.iloc[0]);run=json.loads((folder/'run_receipt.json').read_text())
    assert len(d)==44160 and len(sel)==1200
    assert set(d.model)==MODELS and set(d.policy)==POLICIES
    assert set(d.regime)=={'strict309','expanded441'}
    assert set(d.campaign_id)=={FAMILY} and d.cap.eq(cap).all()
    assert d.log_lower.notna().all()
    assert not d.duplicated(['regime','model','policy','dataset_id','seed','k','row_id']).any()
    taskmap={(t['dataset_id'],t['seed']):t for t in SPLITS['tasks']}
    assert len(taskmap)==40
    checked_prediction_groups=0
    for key,g in d.groupby(['dataset_id','seed','policy','k','regime','model']):
        did,seed,policy,k,regime,model=key;t=taskmap[(did,seed)]
        assert k in t['ks'] and set(g.row_id)==set(t['query_ids']) and len(g)==len(t['query_ids'])
        source=TARGET.loc[g.row_id]
        for c in ['log_life','event','log_stress','load_ratio']:
            assert np.allclose(g[c],source[c],rtol=0,atol=2e-15)
        checked_prediction_groups+=1
    assert checked_prediction_groups==6720
    support_checks=0
    for key,s in sel.groupby(['dataset_id','seed','policy']):
        did,seed,policy=key;t=taskmap[(did,seed)];s=s.sort_values('k')
        assert s.k.tolist()==list(range(1,max(t['ks'])+1))
        assert s.row_id.is_unique and set(s.row_id)<=set(t['pool_ids'])
        assert set(s.row_id).isdisjoint(t['query_ids'])
        for k in t['ks']:
            chosen=s[s.k<=k].row_id.tolist()
            token=hashlib.sha256(json.dumps(chosen).encode()).hexdigest()
            g=d[(d.dataset_id==did)&(d.seed==seed)&(d.policy==policy)&(d.k==k)]
            assert len(g)>0 and g.support_ids_sha256.eq(token).all()
            for field in ['support_cycles_lower','support_cycles_upper','n_support_failure']:
                assert g[field].nunique()==1
            assert g.n_support_failure.eq(s[s.k<=k].revealed_event.sum()).all()
            support_checks+=1
    assert support_checks==560
    paired_keys=['campaign_id','dataset_id','seed','row_id']
    basekeys=['regime','panel','policy','model','k','cap']
    expected_policy=[];expected_training=[];policy_pairs=training_pairs=0
    for key,aa in d.groupby(basekeys,sort=True):
        meta=dict(zip(basekeys,key));a=aa.set_index(paired_keys).sort_index()
        for comparison in ['versus_random','versus_k0']:
            b=d[(d.regime==meta['regime'])&(d.panel==meta['panel'])&(d.model==meta['model'])&
                (d.policy==('random' if comparison=='versus_random' else meta['policy']))&
                (d.k==(meta['k'] if comparison=='versus_random' else 0))].set_index(paired_keys).loc[a.index]
            assert np.array_equal(a.log_life,b.log_life) and np.array_equal(a.event,b.event)
            vals=paired_values(a,b,True);res=balanced_means(a.reset_index(),vals)
            for metric,(mean,nf) in res.items():expected_policy.append(meta|dict(comparison=comparison,metric=metric,mean=mean,n_finite_campaigns=nf))
            policy_pairs+=len(a)
        b=d[(d.regime=='strict309')&(d.panel==meta['panel'])&(d.policy==meta['policy'])&
            (d.model==meta['model'])&(d.k==meta['k'])].set_index(paired_keys).loc[a.index]
        assert a.index.equals(b.index)
        for c in ['log_life','event','log_stress','support_cycles_lower','support_cycles_upper','support_ids_sha256']:
            assert np.array_equal(a[c],b[c])
        vals=paired_values(a,b,False);res=balanced_means(a.reset_index(),vals)
        for metric,(mean,nf) in res.items():expected_training.append(meta|dict(metric=metric,mean=mean,n_finite_campaigns=nf))
        training_pairs+=len(a)
    policy_check=compare_table(pd.DataFrame(expected_policy),folder/'all_policy_contrasts.csv',basekeys+['comparison'])
    training_check=compare_table(pd.DataFrame(expected_training),folder/'training_contrasts.csv',basekeys)
    k0=d[d.k==0]
    h=k0[k0.model=='hierarchical'].set_index(['regime','panel','policy','seed','dataset_id','row_id']).sort_index()
    m=k0[k0.model=='matched_intercept'].set_index(h.index.names).sort_index()
    assert h.index.equals(m.index) and np.array_equal(h.log_lower,m.log_lower)
    for regime in d.regime.unique():
        gates=pd.read_csv(folder/regime/'success_gates.csv')
        assert gates.gate_status.eq('not_evaluable_one_family').all()
        assert gates.gate_evaluable.eq(False).all()
        assert gates[['relative_success','absolute_reliability_supported','full_success']].isna().all().all()
        assert gates[['utility_gain_lo95','true_risk_change_hi95','absolute_upper_risk_hi95']].isna().all().all()
    fitcheck={}
    for regime,f in run['fits'].items():
        assert f['n_rows']==(309 if regime=='strict309' else 441)
        assert FAMILY not in f['training_sources']
        assert not {'10.1016/j.ijfatigue.2024.108491','10.1016/j.ijfatigue.2025.109365'}.intersection(f['training_sources'])
        for name,receipt in f['fits'].items():assert receipt['success']
        rf=f['fits']['rfl'];assert not rf['fallback_active'] and rf['bound_hits']==[]
        parameter_order=['a','b','c_R','log_sigma','mu_log10_gamma','log_tau_log10_gamma']
        param=[rf['params'][k] for k in parameter_order]
        starts=[x for x in rf['starts'] if np.allclose(x['params'],param,rtol=0,atol=1e-14)]
        assert len(starts)==1
        assert starts[0]['objective']==min(x['objective'] for x in rf['starts'] if x['success'])
        fitcheck[regime]=dict(rows=f['n_rows'],source_families=len(f['training_sources']),
            population_models_success=4,RFL_selected_start_gradient_inf=starts[0]['gradient_inf'],
            RFL_fallback_active=False,RFL_bound_hits=[],population_uncertainty_propagated=False)
    diag=json.loads((folder/'prediction_diagnostics.json').read_text())
    local=[x for x in diag if x['model']=='local_slope'];rfl=[x for x in diag if x['model']=='rfl']
    assert all(x['success'] for x in local)
    stale=[x for x in diag if x['model']=='matched_intercept' and x['k']==0 and 'shift' in x]
    result=dict(status='PASS_with_documented_diagnostic_only_caveat',completed_utc=datetime.now(timezone.utc).isoformat(),
        auditor='v3_campaign_papers;standalone pandas/numpy arithmetic;no project imports or fits',
        cap=cap,source_records=67,source_failures=63,source_runouts=4,source_families=1,
        source_panel_counts={'25C':44,'450C':23},predictions=len(d),selections=len(sel),tasks=40,
        common_query_groups_checked=checked_prediction_groups,shared_support_prefixes_checked=support_checks,
        policy_pairs_reconstructed=policy_pairs,training_pairs_reconstructed=training_pairs,
        policy_contrast_check=policy_check,training_contrast_check=training_check,
        inherited_cost_contrast_interpretation=('exact support-cycle difference under5M cap' if cap==5e6 else
            'support_cycle_change is a difference of LOWER cost bounds; not an identified true cost-change interval; use dedicated policy_cost_savings_bounds for conservative savings intervals'),
        one_family_gates='NA,not_evaluable;no95percentpopulationCIorpolicyfailureinterpretation',
        q10_semantics='plug-in predictive10thpercentile;notR90C90andnotphysicalmode-transfervalidation',
        k0_matched_intercept_hierarchical_predictions_exactly_equal=True,
        population_convergence=fitcheck,
        local_prediction_receipts=dict(n=len(local),all_success=True,second_solver_used=sum(x.get('second_solver_used',False) for x in local),slope_bound_hits=sum(x.get('slope_at_bound',False) for x in local),max_gradient_inf=max(x.get('gradient_inf',0) for x in local)),
        RFL_posterior_receipts=dict(n=len(rfl),max_tail_mass_bound=max(x['tail_mass_bound'] for x in rfl),minimum_variance=min(x['variance'] for x in rfl)),
        diagnostic_only_caveat=dict(file='src/v5_rbf.py',lines='149and157-158',unused_matched_intercept_k0_receipts_with_stale_shift=len(stale),total_matched_intercept_k0_receipts=sum(x['model']=='matched_intercept' and x['k']==0 for x in diag),interpretation='k0predictionuseshierarchicalcorrectly;staleshiftmetadatafromunusedobjectmustnotbeinterpretedasak0adaptation'),
        finite_prediction_count=int(np.isfinite(d.log_lower).sum()),positive_infinity_count=int(np.isposinf(d.log_lower).sum()),negative_infinity_count=int(np.isneginf(d.log_lower).sum()),
        inputs_sha256={name:sha(folder/name) for name in ['predictions.csv','selections.csv','all_policy_contrasts.csv','training_contrasts.csv','run_receipt.json','prediction_diagnostics.json']})
    (folder/'independent_contrast_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    assert sha(ROOT/'protocols/v5/rbf_design.txt')==SPLITS['protocol_sha256']
    assert sha(BASE/'target.csv')==SPLITS['target_sha256']
    for filename,expected in SPLITS['code_sha256'].items():
        assert sha(ROOT/'src'/filename)==expected
    for regime,info in SPLITS['regimes'].items():
        assert sha(BASE/f'{regime}.csv')==info['sha256']
        train=pd.read_csv(BASE/f'{regime}.csv')
        assert len(train)==info['rows'] and FAMILY not in set(train.group_id)
        assert set(train.row_id).isdisjoint(TARGET.index)
    math_receipt=check_math()
    result=[audit(ROOT/'results/v5'/x) for x in ['rbf_cap5e6','rbf_cap1e7']]
    # Static acquisition policies are cap-independent; active planning may differ.
    aa=pd.read_csv(ROOT/'results/v5/rbf_cap5e6/selections.csv')
    bb=pd.read_csv(ROOT/'results/v5/rbf_cap1e7/selections.csv')
    idx=['dataset_id','seed','policy','k']
    aa=aa[aa.policy!='active_query_variance'].set_index(idx).sort_index()
    bb=bb[bb.policy!='active_query_variance'].set_index(idx).sort_index()
    assert aa.index.equals(bb.index) and np.array_equal(aa.row_id,bb.row_id)
    review=dict(status='PASS_with_documented_diagnostic_only_caveat',completed_utc=datetime.now(timezone.utc).isoformat(),
        scope='Independent wrapper/design mathematics and saved paired policy/training arithmetic;no fits,no model/summary imports,no frozen-code changes',
        protocol_sha256=sha(ROOT/'protocols/v5/rbf_design.txt'),code_sha256=sha(ROOT/'src/v5_rbf.py'),
        mathematical_risk_bound_check=math_receipt,
        checks=dict(exploratory_source_outcomes_already_seen_disclosed=True,all67source_records_preserved=True,one_source_family_block=True,
            whole_target_family_excluded_from_population_training=True,query_and_candidate_outcomes_absent_from_selector_input=True,
            only_selected_outcomes_revealed=True,common_queries_all_models_populations_policies=True,
            support_sequences_shared_all_models_populations=True,condition_seed_family_balancing_verified=True,
            predictive_q10_not_confidence_design_bound=True,one_family_gates_unavailable=True,
            RBF_to_axial_mode_transfer_limit_disclosed=True,source_runout_lower_bound_not_fabricated_as_exact10Mstop=True,
            static_policy_support_IDs_equal_across_caps=True),
        inherited_cost_metric_note='At1e7, support_cycle_change compares LOWER bounds only; dedicated savings identification intervals must be used for true-cost interpretation',
        static_policy_cross_cap_selection_rows_checked=len(aa),
        per_cap=[{k:r[k] for k in ['cap','predictions','selections','policy_contrast_check','training_contrast_check','population_convergence','diagnostic_only_caveat']} for r in result],
        interpretation='Computationandpairedarithmeticauditonly;doesnotestablishindependentphysicalbuilds,virginstatus,generalsafety,or95percentconfidence')
    (ROOT/'literature/v5_open/rbf/independent_code_review.json').write_text(json.dumps(review,indent=2)+'\n')
    print(json.dumps({k:review[k] for k in ['status','mathematical_risk_bound_check','static_policy_cross_cap_selection_rows_checked']},indent=2))
    for r in result:print(json.dumps({k:r[k] for k in ['cap','policy_contrast_check','training_contrast_check','diagnostic_only_caveat']},indent=2))
